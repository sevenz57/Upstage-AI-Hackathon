// server.js  
import express from 'express';  
import OpenAI from 'openai';  
import bodyParser from 'body-parser';  
  
const app = express();  
const port = 3000;  
  
const apiKey = 'up_LlkCpLlpdCLNFwwxmcp8RPbL2AZjg';  
const openai = new OpenAI({  
    apiKey: apiKey,  
    baseURL: 'https://api.upstage.ai/v1/solar' // 确保这是正确的 URL  
});  
  
app.use(bodyParser.json()); // 使用 bodyParser.json() 来解析 JSON 数据  
app.use(express.static('public'));  
  
app.post('/chat', async (req, res) => {  
    const { userInput } = req.body;  
  
    try {  
        const chatCompletion = await openai.chat.completions.create({  
            model: 'solar-1-mini-chat',  
            messages: [  
                {  
                    role: 'user',  
                    content: userInput  
                }  
            ],  
            // stream: true // 如果您不打算使用流，可以移除这个选项  
        });  
  
        const response = chatCompletion.data.choices[0].message.content;  
        res.send({ response });  
    } catch (error) {  
        console.error('Error:', error);  
        res.status(500).send({ error: 'Internal Server Error' });  
    }  
});  
  
app.listen(port, () => {  
    console.log(`Server running on port ${port}`);  
});